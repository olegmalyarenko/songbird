import AnswerCard from './AnswerCard';

export default AnswerCard;