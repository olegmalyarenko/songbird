import Quiz from './Quiz';

export default Quiz;