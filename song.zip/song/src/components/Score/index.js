import Score from './Score';

export default Score;