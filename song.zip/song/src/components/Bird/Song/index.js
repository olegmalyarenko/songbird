import Song from './Song';

export default Song;