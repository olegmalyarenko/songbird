import Description from "./Description";

export default Description;