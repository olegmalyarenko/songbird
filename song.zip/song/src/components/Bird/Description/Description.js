import React from 'react';

const Description = ({ text }) => {
  return (
    <p>
      {text}
    </p>
  )
};

export default Description;