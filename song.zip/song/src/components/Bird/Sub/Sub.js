import React from 'react';

const Sub = ({ species }) => {
  return (
    <h2>
      {species}
    </h2>
  )
};

export default Sub;