import React, { Component } from 'react';
import birdsData from '../../data/birdsData.js';
import './AnswerList.scss';
console.log(birdsData);

const AnswerList = ({ titles }) => {
  const elements = titles.map((el) => {
    return (
      <li className="answer-item" key={el.id}>
        <span className="chBox"></span>
        {el.name}
      </li>
    )
  });

  return (
    <ul className="answer-list">
      {elements}
    </ul>
  )
};

export default AnswerList;