import AnswerList from './AnswerList';

export default AnswerList;