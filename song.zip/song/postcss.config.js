/* eslint-disable import/no-extraneous-dependencies,global-require */
module.exports = {
  plugins: [
    require('autoprefixer'),
    require('cssnano'),
  ],
};
